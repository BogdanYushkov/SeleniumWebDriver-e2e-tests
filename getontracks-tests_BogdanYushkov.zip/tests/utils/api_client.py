import httpx
import xml.etree.ElementTree as ET


class TracksAPIClient:
    def __init__(self, base_url="http://localhost:3000", username="admin", password="1234567890"):
        self.base_url = base_url
        self.client = httpx.Client(base_url=self.base_url)
        self.login(username, password)

    def login(self, username, password):
        return self.client.post("/login", data={
            "user_login": username,
            "user_password": password,
            "commit": "Login"
        })

    def create_project(self, name, description=None):
        data = {"project[name]": name}
        if description is not None:
            data["project[description]"] = description
        return self.client.post("/projects.xml", data=data)

    def list_projects(self):
        response = self.client.get("/projects.xml")
        response.xml = ET.fromstring(response.text)
        return response

    # 🔁 Старый метод — возвращает просто HTTP-ответ без XML-парсинга
    def get_projects(self):
        return self.client.get("/projects.xml")

    def update_project(self, project_id, name=None, description=None):
        data = {}
        if name is not None:
            data["project[name]"] = name
        if description is not None:
            data["project[description]"] = description
        return self.client.put(f"/projects/{project_id}.xml", data=data)
