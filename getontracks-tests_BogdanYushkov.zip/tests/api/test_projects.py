import pytest
import httpx
import xml.etree.ElementTree as ET
import uuid


def test_FR_001_list_projects_returns_user_projects(api_client, unique_project_name):

    response = api_client.create_project(unique_project_name)
    assert response.status_code == 201

    list_response = api_client.list_projects()
    assert list_response.status_code == 200

    assert unique_project_name in list_response.text


def test_FR_002_project_has_name_and_status(api_client, unique_project_name):

    response = api_client.create_project(unique_project_name)
    assert response.status_code == 201

    list_response = api_client.list_projects()
    assert list_response.status_code == 200
    xml = list_response.text

    assert f"<name>{unique_project_name}</name>" in xml

    assert "<state>" in xml


def test_FR_003_projects_requires_authentication():

    client = httpx.Client(base_url="http://localhost:3000", headers={"Accept": "application/xml"})

    response = client.get("/projects.xml")

    assert response.status_code in [401, 302]


def test_FR_004_create_project_with_unique_name(api_client, unique_project_name):
    response = api_client.create_project(unique_project_name)
    assert response.status_code == 201

    projects_response = api_client.list_projects()
    assert projects_response.status_code == 200
    assert f"<name>{unique_project_name}</name>" in projects_response.text


def test_FR_005_project_name_required_api(api_client):
    response = api_client.create_project("")
    assert response.status_code in (400, 409, 422)

def test_FR_006_project_success_message_api(api_client, unique_project_name):
    response = api_client.create_project(unique_project_name)
    assert response.status_code == 201


def test_FR_007_created_project_visible_in_list_api(api_client, unique_project_name):
    create_response = api_client.create_project(unique_project_name)
    assert create_response.status_code == 201

    list_response = api_client.list_projects()
    assert list_response.status_code == 200

    root = ET.fromstring(list_response.text)
    project_names = [proj.find("name").text for proj in root.findall("project")]

    assert unique_project_name in project_names


def test_FR_008_prevent_duplicate_project_names(api_client, unique_project_name):
    first_response = api_client.create_project(unique_project_name)
    assert first_response.status_code == 201

    second_response = api_client.create_project(unique_project_name)
    assert second_response.status_code in [400, 409, 422]

def test_FR_009_project_name_max_length_api(api_client):
    long_name = "x" * 256
    response = api_client.create_project(long_name)

    assert response.status_code in [409, 422]
    assert "Name project name must be less than 256 characters" in response.text


# FR-010: This test assumes the backend should restrict the project description length to 65535 characters.
# Currently, the backend does not seem to enforce this limit, so the test may fail or pass depending on implementation.

def test_FR_010_project_description_max_length_api(api_client, unique_project_name):
    long_description = "x" * 70000  # exceeds 65535 characters

    response = api_client.create_project(
        name=unique_project_name,
        description=long_description
    )

    assert response.status_code in [400, 422], (
        f"Expected validation error, got {response.status_code}: {response.text}"
    )


def test_FR_011_edit_project_api(api_client, unique_project_name):
    create_response = api_client.create_project(unique_project_name)
    assert create_response.status_code == 201

    list_response = api_client.list_projects()
    assert list_response.status_code == 200

    root = ET.fromstring(list_response.text)
    project_id = None
    for project in root.findall("project"):
        name = project.find("name")
        if name is not None and name.text == unique_project_name:
            project_id = project.find("id").text
            break

    assert project_id is not None, "Project ID not found"

    new_name = unique_project_name + "_edited"
    new_description = "Updated via API test"
    update_response = api_client.update_project(project_id, new_name, new_description)
    assert update_response.status_code == 200


def test_FR_012_project_name_required_on_edit_api(api_client, unique_project_name):
    create_response = api_client.create_project(unique_project_name)
    assert create_response.status_code == 201

    list_response = api_client.list_projects()
    assert list_response.status_code == 200

    project_id = None
    for project in list_response.xml.findall(".//project"):
        if project.find("name").text == unique_project_name:
            project_id = project.find("id").text
            break

    assert project_id is not None, "Project ID not found"

    update_response = api_client.update_project(project_id, name="")
    assert update_response.status_code == 409 or update_response.status_code == 422


def test_FR_013_success_message_after_update_api(api_client, unique_project_name):
    create_response = api_client.create_project(unique_project_name)
    assert create_response.status_code == 201

    list_response = api_client.list_projects()
    assert list_response.status_code == 200

    project_id = None
    for project in list_response.xml.findall(".//project"):
        name = project.find("name").text
        if name == unique_project_name:
            project_id = project.find("id").text
            break

    assert project_id is not None, "Project ID not found"

    update_response = api_client.update_project(project_id, description="Updated via API")
    assert update_response.status_code == 200

    assert "Success" in update_response.text



def test_FR_014_project_changes_reflected_in_list_api(api_client, unique_project_name):
    create_response = api_client.create_project(unique_project_name)
    assert create_response.status_code == 201

    list_response = api_client.list_projects()
    assert list_response.status_code == 200

    project_id = None
    for project in list_response.xml.findall(".//project"):
        name = project.find("name").text
        if name == unique_project_name:
            project_id = project.find("id").text
            break

    assert project_id is not None, f"Project '{unique_project_name}' not found in list"

    updated_description = "Updated by API"
    update_response = api_client.update_project(project_id, description=updated_description)
    assert update_response.status_code == 200

    updated_list = api_client.list_projects()
    assert updated_list.status_code == 200

    for project in updated_list.xml.findall(".//project"):
        if project.find("id").text == project_id:
            desc = project.find("description").text or ""
            assert updated_description in desc
            break
    else:
        pytest.fail(f"Project with ID {project_id} not found in updated list")




def test_FR_015_prevent_duplicate_name_on_edit_api(api_client):

    name_1 = f"project_original_fr015_{uuid.uuid4().hex[:8]}"
    name_2 = f"project_temp_fr015_{uuid.uuid4().hex[:8]}"

    resp1 = api_client.create_project(name_1)
    assert resp1.status_code == 201

    resp2 = api_client.create_project(name_2)
    assert resp2.status_code == 201

    list_response = api_client.list_projects()
    assert list_response.status_code == 200

    project_id_to_edit = None
    for project in list_response.xml.findall(".//project"):
        if project.find("name").text == name_2:
            project_id_to_edit = project.find("id").text
            break

    assert project_id_to_edit is not None, f"Project '{name_2}' not found"

    update_response = api_client.update_project(project_id_to_edit, name=name_1)
    assert update_response.status_code in [400, 409], f"Expected conflict, got {update_response.status_code}"

#FR_016-20 api tests haven't done

