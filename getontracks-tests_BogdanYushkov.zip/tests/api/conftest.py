import pytest
from tests.utils.api_client import TracksAPIClient
import uuid

@pytest.fixture(scope="session")
def api_client():
    return TracksAPIClient()

@pytest.fixture
def unique_project_name():
    return f"test_project_{uuid.uuid4().hex[:8]}"

BASE_URL = "http://localhost:3000"
PROJECTS_ENDPOINT = f"{BASE_URL}/projects"
HEADERS = {
    "Content-Type": "application/x-www-form-urlencoded",
}