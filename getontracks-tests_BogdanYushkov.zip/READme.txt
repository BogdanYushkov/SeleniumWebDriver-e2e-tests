Added automatic report generation.
To run the tests, first start the Docker containers.
Then, in the console where the tests are located, run the command: pytest.
The latest report (which gets overwritten each time) will be available in the reports folder